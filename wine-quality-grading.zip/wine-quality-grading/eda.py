import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from config import PHYSICOCHEMICAL
from labeling import GRADE_ORDER


def plot_eda(df, figure_dir):
    figure_dir.mkdir(parents=True, exist_ok=True)

    counts = df["grade"].value_counts().reindex(GRADE_ORDER)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(GRADE_ORDER, counts.values)
    ax.set_title("Grade distribution")
    ax.set_ylabel("Samples")
    fig.savefig(figure_dir / "grade_distribution.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    cols = PHYSICOCHEMICAL + ["wine_type", "quality"]
    corr = df[cols].corr()
    fig, ax = plt.subplots(figsize=(10, 8))
    im = ax.imshow(corr, cmap="coolwarm", vmin=-1, vmax=1)
    ax.set_xticks(range(len(cols)), cols, rotation=45, ha="right")
    ax.set_yticks(range(len(cols)), cols)
    fig.colorbar(im, ax=ax)
    ax.set_title("Feature correlation")
    fig.savefig(figure_dir / "correlation_heatmap.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    for ax, feature in zip(axes, ["alcohol", "volatile_acidity"]):
        data = [df.loc[df["grade"] == g, feature] for g in GRADE_ORDER]
        ax.boxplot(data)
        ax.set_xticks([1, 2, 3], GRADE_ORDER)
        ax.set_title(feature.replace("_", " "))
    fig.savefig(figure_dir / "boxplots_by_grade.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
