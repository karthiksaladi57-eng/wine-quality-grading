from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.tree import DecisionTreeClassifier

from config import (CLASS_WEIGHT, CV_FOLDS, DT_GRID, FEATURE_COLS, RANDOM_STATE,
                    RF_GRID, TEST_SIZE)


def split_data(df):
    X = df[FEATURE_COLS]
    y = df["grade"]
    return train_test_split(
        X, y, test_size=TEST_SIZE, stratify=y, random_state=RANDOM_STATE
    )


class ModelTrainer:
    param_grid: dict = {}

    def __init__(self):
        self.cv = StratifiedKFold(
            n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE
        )
        self.search = GridSearchCV(
            self.build_estimator(),
            self.param_grid,
            cv=self.cv,
            scoring="f1_macro",
            n_jobs=-1,
        )
        self.best_params_ = None
        self.best_score_ = None

    def build_estimator(self):
        raise NotImplementedError

    def tune(self, X, y):
        self.search.fit(X, y)
        self.best_params_ = self.search.best_params_
        self.best_score_ = float(self.search.best_score_)
        return self.search.best_estimator_


class DecisionTreeTrainer(ModelTrainer):
    param_grid = DT_GRID

    def build_estimator(self):
        return DecisionTreeClassifier(
            random_state=RANDOM_STATE, class_weight=CLASS_WEIGHT
        )


class RandomForestTrainer(ModelTrainer):
    param_grid = RF_GRID

    def build_estimator(self):
        return RandomForestClassifier(
            random_state=RANDOM_STATE, class_weight=CLASS_WEIGHT, n_jobs=-1
        )
