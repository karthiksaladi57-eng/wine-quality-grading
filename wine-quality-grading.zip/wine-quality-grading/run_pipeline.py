import logging

from config import DB_PATH, FIGURE_DIR, RED_PATH, TABLE_DIR, WHITE_PATH
from data_loader import load_wine_data
from eda import plot_eda
from evaluation import compare_models, evaluate, paired_fold_scores
from interpretation import feature_importance_table, save_tree_plot, tree_rules
from labeling import add_grade_column
from storage import init_db, save_run
from training import DecisionTreeTrainer, RandomForestTrainer, split_data

log = logging.getLogger("pipeline")


def main():
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")

    for d in (FIGURE_DIR, TABLE_DIR):
        d.mkdir(parents=True, exist_ok=True)

    log.info("Loading and cleaning data")
    df = add_grade_column(load_wine_data(RED_PATH, WHITE_PATH))
    plot_eda(df, FIGURE_DIR)

    X_train, X_test, y_train, y_test = split_data(df)
    log.info("Train: %d  Test: %d", len(X_train), len(X_test))

    dt_trainer = DecisionTreeTrainer()
    best_dt = dt_trainer.tune(X_train, y_train)
    rf_trainer = RandomForestTrainer()
    best_rf = rf_trainer.tune(X_train, y_train)

    dt_metrics = evaluate(best_dt, X_test, y_test)
    rf_metrics = evaluate(best_rf, X_test, y_test)
    rf_importances = feature_importance_table(best_rf, X_test, y_test)

    conn = init_db(DB_PATH)
    save_run(conn, "decision_tree", dt_trainer.best_params_, dt_trainer.best_score_, dt_metrics)
    save_run(conn, "random_forest", rf_trainer.best_params_, rf_trainer.best_score_,
             rf_metrics, rf_importances)
    conn.close()

    scores_dt, scores_rf = paired_fold_scores(best_dt, best_rf, X_train, y_train)
    p_value = compare_models(scores_dt, scores_rf)

    (TABLE_DIR / "tree_rules.txt").write_text(tree_rules(best_dt, X_train.columns))
    save_tree_plot(best_dt, X_train.columns, FIGURE_DIR / "decision_tree.png")
    rf_importances.to_csv(TABLE_DIR / "rf_feature_importance.csv", index=False)

    log.info("Decision tree  macro F1 %.3f  balanced acc %.3f",
             dt_metrics["macro_f1"], dt_metrics["balanced_accuracy"])
    log.info("Random forest  macro F1 %.3f  balanced acc %.3f",
             rf_metrics["macro_f1"], rf_metrics["balanced_accuracy"])
    log.info("Paired t-test p-value on fold scores: %.4f (optimistic; see README)", p_value)
    log.info("Results saved to %s", DB_PATH)


if __name__ == "__main__":
    main()
