# Wine Quality Grading: Decision Tree vs Random Forest

Predicts a wine's quality grade (Poor, Average, Good) from 11 physicochemical
measurements and a red/white indicator, and compares a single decision tree with a
random forest.

## Results (held-out test set, n = 1,064)

| Metric | Decision Tree | Random Forest |
|---|---|---|
| Macro F1 | 0.487 | 0.490 |
| Balanced accuracy | 0.553 | 0.494 |
| Accuracy | 0.654 | 0.753 |
| ROC AUC (one-vs-rest) | 0.681 | 0.806 |

The random forest is more accurate and ranks wines better. Macro F1 is nearly tied.
Both models struggle with the Poor grade (the forest recalls 3 of 47 Poor wines).
Alcohol is the most important feature.

## Dataset

UCI Wine Quality (red 1,599 rows, white 4,898 rows). After removing 1,177 duplicate
rows, 5,320 remain; split 80/20 stratified into 4,256 train and 1,064 test.

Download `winequality-red.csv` and `winequality-white.csv` from
https://archive.ics.uci.edu/dataset/186/wine+quality and place them in `data/`.

## Setup and run

```bash
pip install -r requirements.txt
python run_pipeline.py
pytest tests/
```

Outputs go to `outputs/` (figures, tree rules, feature importance CSV, and an SQLite
database `experiments.db`).

## Project structure

| File | Purpose |
|---|---|
| `config.py` | Seeds, paths, parameter grids |
| `data_loader.py` | Load, combine, clean the CSV files |
| `labeling.py` | Convert scores to grades |
| `eda.py` | Exploratory plots |
| `training.py` | Stratified split and grid-search tuning |
| `evaluation.py` | Test metrics and fold-level comparison |
| `interpretation.py` | Tree rules, tree plot, permutation importance |
| `storage.py` | SQLite persistence |
| `run_pipeline.py` | Entry point |
| `tests/` | Unit tests for grading and loading |

## Limitations

- Labels are subjective tasting scores.
- The data has no grape variety, origin, or vintage.
- The Poor grade has only 47 test samples, so its numbers are noisy.
- The paired t-test uses overlapping fold scores, so its p-value (below 0.0001)
  overstates the evidence. McNemar's test on the held-out predictions is a better choice.
