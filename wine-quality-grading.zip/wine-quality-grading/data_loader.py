import logging

import pandas as pd

from config import PHYSICOCHEMICAL

log = logging.getLogger(__name__)


def load_wine_data(red_path, white_path) -> pd.DataFrame:
    """Load, combine and clean the UCI red and white wine files."""
    red = pd.read_csv(red_path, sep=";")
    white = pd.read_csv(white_path, sep=";")
    red["wine_type"] = 0
    white["wine_type"] = 1

    df = pd.concat([red, white], ignore_index=True)
    df.columns = df.columns.str.replace(" ", "_")

    required = set(PHYSICOCHEMICAL + ["quality", "wine_type"])
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")

    n_before = len(df)
    df = df.drop_duplicates().reset_index(drop=True)
    log.info("Dropped %d duplicate rows", n_before - len(df))

    if df.isna().any().any():
        raise ValueError("Missing values found; check the source files.")

    return df
