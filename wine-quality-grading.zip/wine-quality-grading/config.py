from pathlib import Path

RANDOM_STATE = 42
TEST_SIZE = 0.2
CV_FOLDS = 5
COMPARISON_REPEATS = 5
CLASS_WEIGHT = "balanced"

RED_PATH = Path("data/winequality-red.csv")
WHITE_PATH = Path("data/winequality-white.csv")
OUTPUT_DIR = Path("outputs")
FIGURE_DIR = OUTPUT_DIR / "figures"
TABLE_DIR = OUTPUT_DIR / "tables"
DB_PATH = OUTPUT_DIR / "experiments.db"

PHYSICOCHEMICAL = [
    "fixed_acidity", "volatile_acidity", "citric_acid", "residual_sugar",
    "chlorides", "free_sulfur_dioxide", "total_sulfur_dioxide", "density",
    "pH", "sulphates", "alcohol",
]
FEATURE_COLS = PHYSICOCHEMICAL + ["wine_type"]

DT_GRID = {
    "max_depth": [3, 5, 7, 10, None],
    "min_samples_leaf": [5, 10, 20],
    "ccp_alpha": [0.0, 0.001, 0.005],
}
RF_GRID = {
    "n_estimators": [200, 500],
    "max_depth": [None, 10, 20],
    "max_features": ["sqrt", 0.5],
}
