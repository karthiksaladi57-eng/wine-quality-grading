import pandas as pd

GRADE_ORDER = ["Poor", "Average", "Good"]


def grade_from_score(q: int) -> str:
    if q <= 4:
        return "Poor"
    if q <= 6:
        return "Average"
    return "Good"


def add_grade_column(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["grade"] = out["quality"].map(grade_from_score)
    return out
