import sys, pathlib
import pandas as pd
import pytest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from labeling import grade_from_score, add_grade_column
from data_loader import load_wine_data
from config import PHYSICOCHEMICAL

HEADER = ["fixed acidity", "volatile acidity", "citric acid", "residual sugar", "chlorides",
          "free sulfur dioxide", "total sulfur dioxide", "density", "pH", "sulphates", "alcohol", "quality"]
ROW_A = [7.4, 0.7, 0, 1.9, 0.076, 11, 34, 0.9978, 3.51, 0.56, 9.4, 5]
ROW_B = [7.8, 0.88, 0, 2.6, 0.098, 25, 67, 0.9968, 3.2, 0.68, 9.8, 6]


def write_csv(path, rows, header=HEADER):
    lines = [";".join(header)] + [";".join(str(v) for v in r) for r in rows]
    path.write_text("\n".join(lines) + "\n")


@pytest.mark.parametrize("q, expected", [(3, "Poor"), (4, "Poor"), (5, "Average"),
                                         (6, "Average"), (7, "Good"), (9, "Good")])
def test_grade_boundaries(q, expected):
    assert grade_from_score(q) == expected


def test_add_grade_column_does_not_modify_input():
    df = pd.DataFrame({"quality": [4, 6, 7]})
    out = add_grade_column(df)
    assert list(out["grade"]) == ["Poor", "Average", "Good"]
    assert "grade" not in df.columns


def test_loader_removes_duplicates_and_adds_wine_type(tmp_path):
    red, white = tmp_path / "red.csv", tmp_path / "white.csv"
    write_csv(red, [ROW_A, ROW_A, ROW_B])
    write_csv(white, [ROW_B])
    df = load_wine_data(red, white)
    # Row B appears in both files but wine_type differs, so only the red duplicate of A is removed.
    assert len(df) == 3
    assert set(df["wine_type"]) == {0, 1}
    assert set(PHYSICOCHEMICAL).issubset(df.columns)


def test_loader_rejects_missing_column(tmp_path):
    red, white = tmp_path / "red.csv", tmp_path / "white.csv"
    bad_header = [h for h in HEADER if h != "pH"]
    write_csv(red, [[v for i, v in enumerate(ROW_A) if HEADER[i] != "pH"]], header=bad_header)
    write_csv(white, [[v for i, v in enumerate(ROW_B) if HEADER[i] != "pH"]], header=bad_header)
    with pytest.raises(ValueError, match="Missing columns"):
        load_wine_data(red, white)


def test_loader_rejects_missing_values(tmp_path):
    red, white = tmp_path / "red.csv", tmp_path / "white.csv"
    row_nan = list(ROW_A)
    row_nan[4] = ""
    write_csv(red, [row_nan])
    write_csv(white, [ROW_B])
    with pytest.raises(ValueError, match="Missing values"):
        load_wine_data(red, white)


def test_loader_missing_file_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_wine_data(tmp_path / "nope.csv", tmp_path / "also_nope.csv")
