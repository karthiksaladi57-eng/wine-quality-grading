from scipy.stats import ttest_rel
from sklearn.base import clone
from sklearn.metrics import (balanced_accuracy_score, confusion_matrix, f1_score,
                             precision_recall_fscore_support, roc_auc_score)
from sklearn.model_selection import RepeatedStratifiedKFold, cross_val_score

from config import COMPARISON_REPEATS, CV_FOLDS, RANDOM_STATE
from labeling import GRADE_ORDER


def evaluate(model, X_test, y_test) -> dict:
    pred = model.predict(X_test)
    proba = model.predict_proba(X_test)

    p, r, f, s = precision_recall_fscore_support(
        y_test, pred, labels=GRADE_ORDER, zero_division=0
    )
    per_class = {
        g: {"precision": float(p[i]), "recall": float(r[i]),
            "f1": float(f[i]), "support": int(s[i])}
        for i, g in enumerate(GRADE_ORDER)
    }

    return {
        "macro_f1": float(f1_score(y_test, pred, average="macro")),
        "balanced_accuracy": float(balanced_accuracy_score(y_test, pred)),
        "roc_auc_ovr": float(roc_auc_score(
            y_test, proba, multi_class="ovr", average="macro",
            labels=model.classes_)),
        "per_class": per_class,
        "confusion": confusion_matrix(y_test, pred, labels=GRADE_ORDER),
    }


def paired_fold_scores(model_a, model_b, X, y):
    """Macro F1 per fold for two models on identical CV splits."""
    cv = RepeatedStratifiedKFold(
        n_splits=CV_FOLDS, n_repeats=COMPARISON_REPEATS, random_state=RANDOM_STATE
    )
    a = cross_val_score(clone(model_a), X, y, cv=cv, scoring="f1_macro", n_jobs=-1)
    b = cross_val_score(clone(model_b), X, y, cv=cv, scoring="f1_macro", n_jobs=-1)
    return a, b


def compare_models(scores_a, scores_b) -> float:
    """Paired t-test p-value. Fold scores overlap, so treat it as optimistic."""
    return float(ttest_rel(scores_a, scores_b).pvalue)
