import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.inspection import permutation_importance
from sklearn.tree import export_text, plot_tree

from config import RANDOM_STATE


def tree_rules(tree, feature_names, max_depth=3) -> str:
    return export_text(tree, feature_names=list(feature_names), max_depth=max_depth)


def save_tree_plot(tree, feature_names, path, max_depth=3):
    fig, ax = plt.subplots(figsize=(16, 8))
    plot_tree(
        tree,
        feature_names=list(feature_names),
        class_names=[str(c) for c in tree.classes_],
        filled=True,
        max_depth=max_depth,
        fontsize=8,
        ax=ax,
    )
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def feature_importance_table(rf, X_test, y_test) -> pd.DataFrame:
    perm = permutation_importance(
        rf, X_test, y_test, scoring="f1_macro",
        n_repeats=10, random_state=RANDOM_STATE, n_jobs=-1,
    )
    table = pd.DataFrame({
        "feature": X_test.columns,
        "impurity_score": rf.feature_importances_,
        "permutation_score": perm.importances_mean,
    })
    return table.sort_values("permutation_score", ascending=False).reset_index(drop=True)
