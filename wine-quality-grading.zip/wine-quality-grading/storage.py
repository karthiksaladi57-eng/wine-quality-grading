import json
import sqlite3
from datetime import datetime, timezone

from config import CLASS_WEIGHT

SCHEMA = """
CREATE TABLE IF NOT EXISTS experiment_run (
    run_id INTEGER PRIMARY KEY AUTOINCREMENT,
    model_type TEXT NOT NULL,
    best_params TEXT NOT NULL,
    class_weight TEXT,
    cv_macro_f1 REAL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS test_result (
    result_id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL REFERENCES experiment_run(run_id),
    macro_f1 REAL,
    balanced_accuracy REAL,
    roc_auc_ovr REAL
);
CREATE TABLE IF NOT EXISTS class_metric (
    metric_id INTEGER PRIMARY KEY AUTOINCREMENT,
    result_id INTEGER NOT NULL REFERENCES test_result(result_id),
    grade TEXT,
    precision REAL,
    recall REAL,
    f1 REAL,
    support INTEGER
);
CREATE TABLE IF NOT EXISTS feature_importance (
    importance_id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL REFERENCES experiment_run(run_id),
    feature_name TEXT,
    impurity_score REAL,
    permutation_score REAL
);
"""


def init_db(db_path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.executescript(SCHEMA)
    return conn


def save_run(conn, model_type, best_params, cv_macro_f1, metrics, importances=None) -> int:
    created = datetime.now(timezone.utc).isoformat()
    cur = conn.execute(
        "INSERT INTO experiment_run (model_type, best_params, class_weight, "
        "cv_macro_f1, created_at) VALUES (?, ?, ?, ?, ?)",
        (model_type, json.dumps(best_params, default=str), CLASS_WEIGHT,
         cv_macro_f1, created),
    )
    run_id = cur.lastrowid

    cur = conn.execute(
        "INSERT INTO test_result (run_id, macro_f1, balanced_accuracy, roc_auc_ovr) "
        "VALUES (?, ?, ?, ?)",
        (run_id, metrics["macro_f1"], metrics["balanced_accuracy"], metrics["roc_auc_ovr"]),
    )
    result_id = cur.lastrowid

    conn.executemany(
        "INSERT INTO class_metric (result_id, grade, precision, recall, f1, support) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        [(result_id, g, m["precision"], m["recall"], m["f1"], m["support"])
         for g, m in metrics["per_class"].items()],
    )

    if importances is not None:
        conn.executemany(
            "INSERT INTO feature_importance (run_id, feature_name, impurity_score, "
            "permutation_score) VALUES (?, ?, ?, ?)",
            [(run_id, row.feature, float(row.impurity_score), float(row.permutation_score))
             for row in importances.itertuples(index=False)],
        )

    conn.commit()
    return run_id
